package com.example.DMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DogManagmentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DogManagmentSystemApplication.class, args);
	}

}
