package com.example.DMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DogManagmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
